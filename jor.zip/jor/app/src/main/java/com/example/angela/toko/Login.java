package com.example.angela.toko;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class Login extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        Button Login=findViewById(R.id.login);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Login.this, Home.class);
                startActivity(i);
            }
        });

        TextView Registrasi=findViewById(R.id.regis);
        Registrasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent (Login.this, Daftar.class);
                startActivity(i);
            }
        });


//        owner contoh
        TextView owner=findViewById(R.id.tulis);
        owner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent (Login.this, OwnerHome.class);
                startActivity(i);
            }
        });

//        manager contoh
        TextView manager=findViewById(R.id.login_title);
        manager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent (Login.this, ManagerHome.class);
                startActivity(i);
            }
        });

    }
}
